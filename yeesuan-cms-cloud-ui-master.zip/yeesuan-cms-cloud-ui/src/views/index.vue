<template>
  <div class="app-container home">
    <div class="content"></div>
    <div class="tex">欢迎使用易算商城后台管理系统</div>
  </div>
</template>

<script>
export default {
  name: "index",
  data() {
    return {
      // 版本号
      version: "3.1.0",
    };
  },
  methods: {
    goTarget(href) {
      window.open(href, "_blank");
    },
  },
};
</script>
<style scoped>
.home{
 width: 100%;
  min-height: calc(100vh - 84px);
 transform: translate(0px , -12%);
 display: flex;
 justify-content: center;
 align-items: center;
}
.content{
  width: 160px;
  height: 160px;
  margin-right: 20px;
  background-image: url('../assets/images/background.png');
  background-position: -314px -205px;
}
.tex{
  font-size: 40px;
  font-family: fangsong;
  font-weight: bold;
  color: #2E4096;
}
</style>
