<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="栏目位置" prop="location">
        <el-select v-model="queryParams.location" placeholder="请选择栏目位置" clearable size="small">
          <el-option
            v-for="dict in locationOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="栏目编号" prop="fenceCode">
        <el-select v-model="queryParams.fenceCode" placeholder="请选择栏目编号" clearable size="small">
          <el-option
            v-for="dict in fenceCodeOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="领域名称" prop="fieldId">
        <el-select v-model="queryParams.fieldId" placeholder="请选择领域名称" clearable size="small">
          <el-option
            v-for="item in fields"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['biz:frontFence:add']"
        >新增
        </el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['biz:frontFence:edit']"
        >修改
        </el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['biz:frontFence:remove']"
        >删除
        </el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['biz:frontFence:export']"
        >导出
        </el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="frontFenceList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center"/>
      <el-table-column label="栏目位置" align="center" prop="location" :formatter="locationFormat"/>
      <el-table-column label="栏目编号" align="center" prop="fenceCode" :formatter="fenceCodeFormat"/>
      <el-table-column label="领域名称" align="center" prop="fieldName"/>
      <el-table-column label="软件版本" align="center" prop="appVersionName"/>
      <el-table-column label="排序" align="center" prop="appSort"/>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['biz:frontFence:edit']"
          >修改
          </el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['biz:frontFence:remove']"
          >删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改栏目软件对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="栏目位置" prop="location">
          <el-select v-model="form.location" placeholder="请选择栏目位置">
            <el-option
              v-for="dict in locationOptions"
              :key="dict.dictValue"
              :label="dict.dictLabel"
              :value="dict.dictValue"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="栏目编号" prop="fenceCode">
          <el-select v-model="form.fenceCode" placeholder="请选择栏目编号">
            <el-option
              v-for="dict in fenceCodeOptions"
              :key="dict.dictValue"
              :label="dict.dictLabel"
              :value="dict.dictValue"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="领域名称" prop="fieldId">
          <el-select v-model="form.fieldId" placeholder="请选择领域名称" @change="fieldChange">
            <el-option
              v-for="item in fields"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="软件版本" prop="appItemId">
          <el-select v-model="form.appItemId" :placeholder="isText2" :disabled="isDisabled2">
            <el-option
              v-for="item in appItems"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="排序" prop="appSort">
            <el-input-number v-model="form.appSort" controls-position="right" :min="0" />
        </el-form-item>


      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  listFrontFence,
  getFrontFence,
  delFrontFence,
  addFrontFence,
  updateFrontFence,
  exportFrontFence,
  getFileds,
  getApps,
  getAppItems
} from "@/api/biz/frontFence";

export default {
  name: "FrontFence",
  components: {},
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 栏目软件表格数据
      frontFenceList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 栏目位置字典
      locationOptions: [],
      // 栏目编号字典
      fenceCodeOptions: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        location: null,
        fenceCode: null,
        appItemId: null,
        appSort: null,
        fieldId: null,
        appVersionName: null,
        fieldName: null

      },
      // 表单参数
      form: {},
      // 表单校验
      // 表单校验
      rules: {
        location: [{required: true, message: '栏目位置不能为空', trigger: 'blur'}],
        fenceCode: [{required: true, message: '栏目编号不能为空', trigger: 'blur'}],
        fieldId: [{required: true, message: '领域名称不能为空', trigger: 'blur'}],
        appItemId: [{required: true, message: '软件版本不能为空', trigger: 'blur'}]
      },
      apps: [],
      fields: [],
      appItems: [],
      fenceDTO:[],
      isDisabled1: true,
      isDisabled2: true,
      isText1: "请先选择领域名称",
      isText2: "请先选择软件名称"
    };
  },
  created() {
    this.getList();
    this.getDicts("aoh_side_location").then(response => {
      this.locationOptions = response.data;
    });
    this.getDicts("fence_code").then(response => {
      this.fenceCodeOptions = response.data;
    });
    getFileds().then(response => {
      this.fields = response.data;
    });

  },
  methods: {
    /** 查询栏目软件列表 */
    getList() {
      this.loading = true;
      listFrontFence(this.queryParams).then(response => {
        this.frontFenceList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 栏目位置字典翻译
    locationFormat(row, column) {
      return this.selectDictLabel(this.locationOptions, row.location);
    },
    // 栏目编号字典翻译
    fenceCodeFormat(row, column) {
      return this.selectDictLabel(this.fenceCodeOptions, row.fenceCode);
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        location: null,
        fenceCode: null,
        appItemId: null,
        appSort: null,
        fieldId: null
      };
      this.resetForm("form");
      this.isDisabled1 = true;
      this.isDisabled2 = true;
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length !== 1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加栏目软件";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getFrontFence(id).then(response => {
        this.form = response.data;
        this.fieldChange(this.form.fieldId, true);
        this.open = true;
        this.title = "修改栏目软件";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateFrontFence(this.form).then(response => {
              this.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addFrontFence(this.form).then(response => {
              this.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
        this.isText1 = "请先选择领域名称";
        this.isText2 = "请先选择软件名称";
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$confirm('是否确认删除栏目软件编号为"' + ids + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function () {
        return delFrontFence(ids);
      }).then(() => {
        this.getList();
        this.msgSuccess("删除成功");
      })
    },
    /** 导出按钮操作 */
    handleExport() {
      const queryParams = this.queryParams;
      this.$confirm('是否确认导出所有栏目软件数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function () {
        return exportFrontFence(queryParams);
      }).then(response => {
        this.download(response.msg);
      })
    },
    fieldChange(fieldId, isUpdate) {
      getApps(fieldId).then(response => {
        if(!isUpdate) {
          this.form.appItemId = '';
        }
        this.appItems = response.data;
        this.isDisabled2 = false;
        this.isText2 = "请选择软件版本"
      })
    }
  }
};
</script>
