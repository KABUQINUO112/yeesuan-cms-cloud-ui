<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="110px">
      <el-form-item label="侧边栏位置" prop="sideLocation">
        <el-input
          v-model="queryParams.sideLocation"
          placeholder="请输入侧边栏位置"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="侧边栏名称" prop="sideName">
        <el-select v-model="queryParams.sideName" placeholder="请选择侧边栏名称" clearable size="small">
        <el-option
            v-for="dict in frontSideLists"
            :key="dict.id"
            :label="dict.sideName"
            :value="dict.sideName"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="状态" prop="status">
        <el-select v-model="queryParams.status" placeholder="请选择状态" clearable size="small">
          <el-option
            v-for="dict in statusOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['biz:frontSide:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['biz:frontSide:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['biz:frontSide:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['biz:frontSide:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="frontSideList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <!-- <el-table-column label="" align="center" prop="id" /> -->
      <el-table-column label="侧边栏位置" align="center" prop="sideLocation" :formatter="sideLocationFormat"/>
      <el-table-column label="侧边栏名称" align="center" prop="sideName" />

      <!-- <el-table-column label="状态" align="center" prop="status" :formatter="statusFormat" /> -->

      <el-table-column label="状态" align="center" prop="status">
              <template slot-scope="scope">
                <el-switch
                  v-model="scope.row.status"
                  active-value="0"
                  inactive-value="1"
                  @change="handleStatusChange(scope.row)"
                ></el-switch>
              </template>
      </el-table-column>

      <el-table-column label="排序" align="center" prop="sideSort" />

      <el-table-column label="备注" align="center" prop="remark" />
      <!-- <el-table-column label="删除人" align="center" prop="delBy" />
      <el-table-column label="删除时间" align="center" prop="delTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.delTime, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column> -->
      <!-- <el-table-column label="分类编码" align="center" prop="sideCode" /> -->
      <!-- <el-table-column label="逻辑删除" align="center" prop="deleted" /> -->
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['biz:frontSide:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['biz:frontSide:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改侧边栏管理对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body :close-on-click-modal="false">
      <el-form ref="form" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="侧边栏位置" prop="sideLocation">
          <el-select v-model="form.sideLocation" placeholder="请输入侧边栏位置" clearable size="small">
          <el-option
            v-for="dict in sideLocationOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>

        </el-form-item>
        <el-form-item label="侧边栏名称" prop="sideName">
          <el-input v-model="form.sideName" placeholder="请输入侧边栏名称" />
        </el-form-item>
        <el-form-item label="排序" prop="sideSort">
          <el-input-number v-model="form.sideSort" controls-position="right" :min="0" />
        </el-form-item>
        <el-form-item label="状态">
          <el-radio-group v-model="form.status">
            <el-radio
              v-for="dict in statusOptions"
              :key="dict.dictValue"
              :label="dict.dictValue"
            >{{dict.dictLabel}}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" placeholder="请输入备注" />
        </el-form-item>
        <!-- <el-form-item label="删除人" prop="delBy">
          <el-input v-model="form.delBy" placeholder="请输入删除人" />
        </el-form-item> -->
        <!-- <el-form-item label="删除时间" prop="delTime">
          <el-date-picker clearable size="small"
            v-model="form.delTime"
            type="date"
            value-format="yyyy-MM-dd"
            placeholder="选择删除时间">
          </el-date-picker>
        </el-form-item> -->
        <!-- <el-form-item label="分类编码" prop="sideCode">
          <el-input v-model="form.sideCode" placeholder="请输入分类编码" />
        </el-form-item> -->
        <!-- <el-form-item label="逻辑删除" prop="deleted">
          <el-input v-model="form.deleted" placeholder="请输入逻辑删除" />
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listFrontSide, getFrontSide, delFrontSide, addFrontSide, updateFrontSide, exportFrontSide, changeStatus,getFrontSideList } from "@/api/biz/frontSide";

export default {
  name: "FrontSide",
  components: {
  },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 侧边栏管理表格数据
      frontSideList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 状态(0:正常,1:停用)字典
      statusOptions: [],
      // banner位置字典
      sideLocationOptions: [],
      //frontSideList
      frontSideLists: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        sideLocation: null,
        sideName: null,
        sideSort: null,
        status: null,
        delBy: null,
        delTime: null,
        sideCode: null,
        deleted: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        sideLocation: [{ required: true, message: '侧边栏页面地址不能为空', trigger: 'blur' }],
        sideName: [{ required: true, message: '侧边栏名称不能为空', trigger: 'blur' }]
      }
    };
  },
  created() {
    this.getList();
    this.getDicts("aoh_data_status").then(response => {
      this.statusOptions = response.data;
    });
    this.getDicts("aoh_side_location").then(response => {
      this.sideLocationOptions = response.data;
    });
    getFrontSideList().then(response => {
      this.frontSideLists = response.data;
    });
  },
  methods: {
    /** 查询侧边栏管理列表 */
    getList() {
      this.loading = true;
      listFrontSide(this.queryParams).then(response => {
        this.frontSideList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 状态(0:是,1:否)字典翻译
    statusFormat(row, column) {
      return this.selectDictLabel(this.statusOptions, row.status);
    },
    // banner位置字典翻译
    sideLocationFormat(row, column) {
      return this.selectDictLabel(this.sideLocationOptions, row.sideLocation);
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        sideLocation: null,
        sideName: null,
        sideSort: null,
        status: "0",
        remark: null,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        delBy: null,
        delTime: null,
        sideCode: null,
        deleted: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加侧边栏管理";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getFrontSide(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改侧边栏管理";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateFrontSide(this.form).then(response => {
              this.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addFrontSide(this.form).then(response => {
              this.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$confirm('是否确认删除侧边栏管理编号为"' + ids + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delFrontSide(ids);
        }).then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        })
    },
    /** 修改状态 */
    handleStatusChange(row) {
      let text = row.status === "0" ? "启用" : "停用";
      this.$confirm('确认要' + text + '该数据吗?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return changeStatus(row.id, row.status);
        }).then(() => {
          this.msgSuccess(text + "成功");
        }).catch(function() {
          row.status = row.status === "0" ? "1" : "0";
        });
    },
    /** 导出按钮操作 */
    handleExport() {
      const queryParams = this.queryParams;
      this.$confirm('是否确认导出所有侧边栏管理数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return exportFrontSide(queryParams);
        }).then(response => {
          this.download(response.msg);
        })
    }
  }
};
</script>
