<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="98px">
      <el-form-item label="推荐软件类型" prop="type">
        <el-select v-model="queryParams.type" placeholder="请选择推荐软件类型" clearable size="small">
          <el-option
            v-for="dict in typeOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="用户名称" prop="userId">
        <el-select v-model="queryParams.userId" placeholder="请选择用户名称" clearable size="small">
          <el-option v-for="item in SysUserList"
                     :key="item.userId"
                     :label="item.userName"
                     :value="item.userId"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="主软件id" prop="appMainId">
        <el-select v-model="queryParams.appMainId" placeholder="请选择主软件名称" clearable size="small">
          <el-option v-for="item in AppMainList"
                     :key="item.id"
                     :label="item.name"
                     :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['biz:homeRecAppUser:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['biz:homeRecAppUser:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['biz:homeRecAppUser:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['biz:homeRecAppUser:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="homeRecAppUserList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="推荐软件类型" align="center" prop="type" :formatter="typeFormat" />
      <el-table-column label="用户名称" align="center" prop="userName" />
      <el-table-column label="主软件名称" align="center" prop="name" />
      <el-table-column label="创建时间" align="center" prop="creatTime" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <!-- <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['biz:homeRecAppUser:edit']"
          >修改</el-button> -->
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['biz:homeRecAppUser:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改用户和首页软件推荐关联对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="推荐软件类型">
          <el-radio-group v-model="form.type" @change ="changeType">
            <el-radio
              v-for="dict in typeOptions"
              :key="dict.dictValue"
              :label="dict.dictValue"
            >{{dict.dictLabel}}</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="用户名称" prop="userId" v-show="showUserList">
          <el-select v-model="form.userId" placeholder="请选择用户名称" filterable clearable >
            <el-option v-for="item in SysUserList"
                       :key="item.userId"
                       :label="item.userName"
                       :value="item.userId"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="主软件名称" prop="appMainId">
          <el-select v-model="form.appMainId" placeholder="请选择主软件名称" filterable clearable >
            <el-option v-for="item in AppMainList"
                       :key="item.id"
                       :label="item.name"
                       :value="item.id"
            />
          </el-select>
        </el-form-item>
        <!-- <el-form-item label="创建时间" prop="creatTime">
          <el-date-picker clearable size="small"
            v-model="form.creatTime"
            type="datetime"
            value-format="yyyy-MM-dd HH:mm:ss"
            placeholder="选择创建时间">
          </el-date-picker>
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listHomeRecAppUser, getHomeRecAppUser, delHomeRecAppUser, addHomeRecAppUser, updateHomeRecAppUser, getAppMainList, getSysUserList } from "@/api/biz/homeRecAppUser";

export default {
  name: "HomeRecAppUser",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 用户和首页软件推荐关联表格数据
      homeRecAppUserList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 推荐软件类型字典
      typeOptions: [],
      //
      AppMainList: [],
      //
      SysUserList: [],
      //
      showUserList: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        type: null,
        userId: 0,
        appMainId: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      }
    };
  },
  created() {
    this.getList();
    this.getDicts("app_recommend_type").then(response => {
      this.typeOptions = response.data;
    });
    getAppMainList().then(response => {
      this.AppMainList = response.rows;
    });

    getSysUserList().then(response => {
      this.SysUserList = response.data;
    });

  },
  methods: {
    /** 查询用户和首页软件推荐关联列表 */
    getList() {
      this.loading = true;
      listHomeRecAppUser(this.queryParams).then(response => {
        this.homeRecAppUserList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 推荐软件类型字典翻译
    typeFormat(row, column) {
      return this.selectDictLabel(this.typeOptions, row.type);
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
      this.changeType(0);
    },
    // 表单重置
    reset() {
      this.form = {
        type: "0",
        userId: null,
        appMainId: null,
        creatTime: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.userId)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.changeType(0);
      this.reset();
      this.open = true;
      this.title = "添加用户和首页软件推荐关联";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const userId = row.userId || this.ids
      getHomeRecAppUser(userId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改用户和首页软件推荐关联";
        this.changeType(this.form.type);
      });
    },
    /** 提交按钮 */
    submitForm() {
      if(this.form.userId ==null){
        this.form.userId = 0;
      }
      this.$refs["form"].validate(valid => {
        if (valid) {

          addHomeRecAppUser(this.form).then(response => {
            this.msgSuccess("新增成功");
            this.open = false;
            this.getList();
          });

        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      let userIds = null;
      if (row.userId == null){
        userIds = this.ids;
      }else{
        userIds = row.userId
      }
      const appMainId =  row.appMainId;
      this.$confirm('是否确认删除用户和首页软件推荐关联编号为"' + userIds + '"软件编号为"' + appMainId + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        return delHomeRecAppUser(userIds,appMainId);
      }).then(() => {
        this.getList();
        this.msgSuccess("删除成功");
      }).catch(() => {});
    },

    /** 导出按钮操作 */
    handleExport() {
      this.download('biz/homeRecAppUser/export', {
        ...this.queryParams
      }, `biz_homeRecAppUser.xlsx`)
    },
    changeType(e){
      // console.log("eeeeeeeee_____________>>",e);
      if(e == 0){
        this.showUserList = false;
      }else if(e == 1){
        this.showUserList = true;
      }
    }

  }
};
</script>
