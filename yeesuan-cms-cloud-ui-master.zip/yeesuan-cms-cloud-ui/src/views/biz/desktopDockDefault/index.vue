<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
      <!-- <el-form-item label="上一级ID" prop="parentId">
        <el-input
          v-model="queryParams.parentId"
          placeholder="请输入上一级ID"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item> -->
      <el-form-item label="名称" prop="chineseName">
        <el-input
          v-model="queryParams.chineseName"
          placeholder="请输入名称"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="路由" prop="name">
        <el-input
          v-model="queryParams.name"
          placeholder="请输入路由"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
    <!--  <el-form-item label="是否文件夹 " prop="isFolder" label-width="100px">
        <el-select v-model="queryParams.isFolder" placeholder="请选择是否文件夹 " clearable size="small">
          <el-option
            v-for="dict in isFolderOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>
      </el-form-item> -->
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['biz:desktopDockDefault:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['biz:desktopDockDefault:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['biz:desktopDockDefault:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['biz:desktopDockDefault:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="deskTopDockDefaultList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <!-- <el-table-column label="主键id" align="center" prop="id" /> -->
      <!-- <el-table-column label="上一级ID" align="center" prop="parentId" /> -->
      <el-table-column label="名称" align="center" prop="chineseName" />
      <el-table-column label="路由" align="center" prop="name" />
      <!-- <el-table-column label="是否文件夹 " align="center" prop="isFolder" :formatter="isFolderFormat" /> -->
      <el-table-column label="logo" align="center" prop="logoUrl" >
        <template slot-scope="scope">
        <el-image style="width:100px;height:100px;" class="image" :src="uploadUrl + scope.row.logoUrl" />
        </template>
      </el-table-column>
      <el-table-column label="窗口宽度" align="center" prop="width" />
      <el-table-column label="窗口高度" align="center" prop="height" />
      <el-table-column label="位置排序" align="center" prop="sort" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['biz:desktopDockDefault:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['biz:desktopDockDefault:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改dock默认应用管理对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body :close-on-click-modal="false">
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
       <!-- <el-form-item label="上一级ID" prop="parentId">
          <el-input v-model="form.parentId" placeholder="请输入上一级ID" />
        </el-form-item> -->
        <el-form-item label="名称" prop="chineseName">
          <el-input v-model="form.chineseName" placeholder="请输入名称" />
        </el-form-item>
        <el-form-item label="路由" prop="name">
          <el-input v-model="form.name" placeholder="请输入路由" />
        </el-form-item>
        <el-form-item label="是否文件夹 " v-show="false">
          <el-radio-group v-model="form.isFolder">
            <el-radio
              v-for="dict in isFolderOptions"
              :key="dict.dictValue"
              :label="parseInt(dict.dictValue)"
            >{{dict.dictLabel}}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="logo">
          <imageUpload v-model="form.logoUrl"/>
        </el-form-item>
        <el-form-item label="窗口宽度" prop="width">
          <el-input v-model="form.width" placeholder="请输入窗口宽度" />
        </el-form-item>
        <el-form-item label="窗口高度" prop="height">
          <el-input v-model="form.height" placeholder="请输入窗口高度" />
        </el-form-item>
        <el-form-item label="位置排序" prop="sort">
          <el-input v-model="form.sort" placeholder="请输入位置排序" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listDeskTopDockDefault, getDeskTopDockDefault, delDeskTopDockDefault, addDeskTopDockDefault, updateDeskTopDockDefault, exportDeskTopDockDefault } from "@/api/biz/desktopDockDefault";
import ImageUpload from '@/components/ImageUpload';

export default {
  name: "DeskTopDockDefault",
  components: {
    ImageUpload,
  },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // dock默认应用管理表格数据
      deskTopDockDefaultList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 是否文件夹 字典
      isFolderOptions: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        parentId: null,
        chineseName: null,
        name: null,
        isFolder: null,
        logoUrl: null,
        width: null,
        height: null,
        sort: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        // parentId: [
        //   { required: true, message: "上一级ID不能为空", trigger: "blur" }
        // ],
        name: [
          { required: true, message: "路由不能为空", trigger: "blur" }
        ],
        chineseName: [
          { required: true, message: "名称不能为空", trigger: "blur" }
        ],
      },
      uploadUrl: process.env.VUE_APP_BASE_API + "/file"
    };
  },
  created() {
    this.getList();
    this.getDicts("aoh_is_folder").then(response => {
      this.isFolderOptions = response.data;
    });
  },
  methods: {
    /** 查询dock默认应用管理列表 */
    getList() {
      this.loading = true;
      listDeskTopDockDefault(this.queryParams).then(response => {
        this.deskTopDockDefaultList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 是否文件夹 字典翻译
    isFolderFormat(row, column) {
      return this.selectDictLabel(this.isFolderOptions, row.isFolder);
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        parentId: null,
        chineseName: null,
        name: null,
        isFolder: 0,
        logoUrl: null,
        width: null,
        height: null,
        sort: null,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        deleted: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加dock默认应用";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getDeskTopDockDefault(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改dock默认应用管理";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateDeskTopDockDefault(this.form).then(response => {
              this.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addDeskTopDockDefault(this.form).then(response => {
              this.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$confirm('是否确认删除dock默认应用管理编号为"' + ids + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delDeskTopDockDefault(ids);
        }).then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        })
    },
    /** 导出按钮操作 */
    handleExport() {
      const queryParams = this.queryParams;
      this.$confirm('是否确认导出所有dock默认应用管理数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return exportDeskTopDockDefault(queryParams);
        }).then(response => {
          this.download(response.msg);
        })
    }
  }
};
</script>
