<template>

  <div class="app-container">

    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="集群名称" prop="clusterName">
        <template>
          <el-select v-model="queryParams.clusterId" placeholder="请选择">
            <el-option
              v-for="cluster in allClusterList"
              :key="cluster.clusterId"
              :label="cluster.clusterName"
              :value="cluster.clusterId">
            </el-option>
          </el-select>
        </template>
      </el-form-item>
      <el-form-item label="集群账号" prop="ldapIp">
        <el-input
          v-model="queryParams.ldapUsername"
          placeholder="集群账号"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['aoh:account:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['aoh:account:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['aoh:account:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['aoh:account:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="accountList" @selection-change="handleSelectionChange">
      <el-table-column label="集群名称" align="center" prop="clusterName" />
      <el-table-column label="登录节点ip" align="center" prop="loginNodeIp" />
      <el-table-column label="登录节点端口" align="center" prop="loginNodePort" />
      <el-table-column label="集群账号" align="center" prop="ldapUsername" />
      <el-table-column label="账号类型" align="center" prop="ldapType" >
        <template slot-scope="scope">
          <span>{{selectDictLabel(ldapTypeOptions,scope.row.ldapType)}}</span>
        </template>
      </el-table-column>

      <el-table-column label="备注" align="center" prop="remark" />
      <el-table-column label="设置为测试账号" align="center" prop="ldapType" >
        <template slot-scope="scope">
          <el-button type="primary" @click="handleUpdateTestAccount(scope.row)"> 测试账号</el-button>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleDetail(scope.row)"
            v-hasPermi="['aoh:account:edit']"
          >详情</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['aoh:account:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['aoh:account:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改ldap拉取的账号对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="集群名称" prop="clusterId">
          <el-input v-model="form.clusterName" placeholder="集群名称"  disabled/>
        </el-form-item>
        <el-form-item label="登录节点" prop="ldapUid">
          <el-select v-model="form.loginNodeId" placeholder="请选择">
            <el-option
              v-for="loginNode in loginNodeOptions"
              :key="loginNode.loginNodeId"
              :label="loginNode.loginNodeIp+':'+loginNode.loginNodePort"
              :value="loginNode.loginNodeId">
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="集群账号" prop="ldapUid">
          <el-input v-model="form.ldapUid" placeholder="集群账号"  disabled/>
        </el-form-item>
        <el-form-item label="账号类型" prop="ldapType">
          <template slot-scope="scope">
            <el-input :value="selectDictLabel(ldapTypeOptions,form.ldapType)" disabled></el-input>
          </template>
        </el-form-item>

        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" placeholder="请输入备注" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>


    <el-dialog :title="title" :visible.sync="detailOpen" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="ldap中的uid" prop="ldapUid">
          <el-input v-model="form.ldapUid" placeholder="" disabled/>
        </el-form-item>
        <el-form-item label="ldap中的uid_numer" prop="ldapUidNumber">
          <el-input v-model="form.ldapUidNumber" placeholder=""disabled />
        </el-form-item>
        <el-form-item label="ldap中的gid_numer" prop="ldapGidNumber">
          <el-input v-model="form.ldapGidNumber" placeholder="" disabled/>
        </el-form-item>
        <el-form-item label="ldap中cn" prop="cn">
          <el-input v-model="form.cn" placeholder="" disabled/>
        </el-form-item>
        <el-form-item label="ldap中sn" prop="sn">
          <el-input v-model="form.sn" placeholder="" disabled/>
        </el-form-item>
        <el-form-item label="ldap中的login_shell" prop="loginShell">
          <el-input v-model="form.loginShell" placeholder="" disabled/>
        </el-form-item>
        <el-form-item label="ldap中的givenName" prop="givenName">
          <el-input v-model="form.givenName" placeholder="" disabled/>
        </el-form-item>
        <el-form-item label="ldap中displayName" prop="displayName">
          <el-input v-model="form.displayName" placeholder="" disabled/>
        </el-form-item>
        <el-form-item label="ldap中的userName对应uid" prop="ldapUsername">
          <el-input v-model="form.ldapUsername" placeholder="" disabled/>
        </el-form-item>
        <el-form-item label="ldap中的password" prop="ldapPassword">
          <el-input v-model="form.ldapPassword" type="password" placeholder="" />
        </el-form-item>
        <el-form-item label="家目录" prop="homeDir">
          <el-input v-model="form.homeDir" placeholder="" disabled/>
        </el-form-item>

        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" placeholder="请输入备注"  disabled/>
        </el-form-item>
      </el-form>
    </el-dialog>

  </div>
</template>

<script>
import { listAccount, getAccount, delAccount, addAccount, updateAccount, exportAccount ,updateTestAccount} from "@/api/ldap/account";
import {allListNode} from "@/api/ldap/node";
import {getInfo} from "../../../api/login";
import {allListCluster} from "@/api/ldap/cluster";

import {getDetail} from "../../../api/ldap/account";

export default {
  name: "Account",
  components: {
  },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // ldap拉取的账号表格数据
      accountList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        clusterId: null,
        ldapUid: null,
        ldapUidNumber: null,
        ldapGidNumber: null,
        cn: null,
        sn: null,
        loginShell: null,
        givenName: null,
        displayName: null,
        ldapUsername: null,
        ldapPassword: null,
        homeDir: null,
        aohGroupId: null,
        status: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      },
      statusOptions:[],
      loginNodeOptions:[],
      detailOpen:false,
      allClusterList:[],
      ldapTypeOptions:[],
    };
  },
  created() {
    this.getList();
    this.getDicts("sys_normal_disable").then(response => {
      this.statusOptions = response.data;
    });
    this.getDicts("ldap_type").then(response=>{
      this.ldapTypeOptions=response.data;
    })
    this.getAllClusterList();
  },
  methods: {

    /** 查询ldap拉取的账号列表 */
    getList() {
      this.loading = true;
      listAccount(this.queryParams).then(response => {
        this.accountList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        ldapAccountId: null,
        clusterId: null,
        ldapUid: null,
        ldapUidNumber: null,
        ldapGidNumber: null,
        cn: null,
        sn: null,
        loginShell: null,
        givenName: null,
        displayName: null,
        ldapUsername: null,
        ldapPassword: null,
        homeDir: null,
        aohGroupId: null,
        status: "0",
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null
      };
      this.queryParams={
        pageNum: 1,
        pageSize: 10,
        clusterId: null,
        ldapUid: null,
        ldapUidNumber: null,
        ldapGidNumber: null,
        cn: null,
        sn: null,
        loginShell: null,
        givenName: null,
        displayName: null,
        ldapUsername: null,
        ldapPassword: null,
        homeDir: null,
        aohGroupId: null,
        status: null,
      },
        this.resetForm("form");
    },
    getAllClusterList(){
      allListCluster().then(res=>{
        this.allClusterList=res.data;
      })
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.reset();

      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.ldapAccountId)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /*详情按钮操作**/
    handleDetail(row){
      this.detailOpen=true;
      const ldapAccountId = row.ldapAccountId
      getDetail(ldapAccountId).then(res=>{
        this.form=res.data
      })


    },
    handleUpdateTestAccount(row){
      updateTestAccount(row).then(res=>{
        this.$message.success("已重置测试账号");
        this.getList();
      })
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加ldap拉取的账号";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const ldapAccountId = row.ldapAccountId
      getAccount(ldapAccountId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改ldap拉取的账号";
        allListNode(query).then(res=>{
          this.loginNodeOptions=res.data
        })
      });
      const  clusterId=row.clusterId

      let query={
        clusterId,
      }

    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.ldapAccountId != null) {
            updateAccount(this.form).then(response => {
              this.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addAccount(this.form).then(response => {
              this.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ldapAccountIds = row.ldapAccountId || this.ids;
      this.$confirm('是否确认删除ldap拉取的账号编号为"' + ldapAccountIds + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        return delAccount(ldapAccountIds);
      }).then(() => {
        this.getList();
        this.msgSuccess("删除成功");
      })
    },
    /** 导出按钮操作 */
    handleExport() {
      const queryParams = this.queryParams;
      this.$confirm('是否确认导出所有ldap拉取的账号数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        return exportAccount(queryParams);
      }).then(response => {
        this.download(response.msg);
      })
    }
  }
};
</script>
