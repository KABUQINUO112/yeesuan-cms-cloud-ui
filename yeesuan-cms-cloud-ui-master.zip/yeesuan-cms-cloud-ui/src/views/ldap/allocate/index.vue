<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="用户名称" prop="userName">
        <el-input
          v-model="queryParams.userName"
          placeholder="集群账号"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="用户昵称" prop="nickName">
        <el-input
          v-model="queryParams.nickName"
          placeholder="集群账号"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>

      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-table v-loading="loading" :data="ldapAllocateDTOList" @selection-change="handleSelectionChange">
      <el-table-column label="用户名称" align="center" prop="userName" />
      <el-table-column label="用户昵称" align="center" prop="nickName" />
      <el-table-column label="使用的集群" align="center" prop="clusterName" >
        <template slot-scope="scope">
          <span v-if="scope.row.clusterName==null||scope.row.clusterName==''">无</span>
          <span v-else>{{scope.row.clusterName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="使用的集群账号" align="center" prop="ldapUserName" >
        <template slot-scope="scope">
          <span v-if="scope.row.ldapUserName==null||scope.row.ldapUserName==''">无</span>
          <span v-else>{{scope.row.ldapUserName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="使用的登录节点ip" align="center" prop="ldapLoginNodeIp" >
        <template slot-scope="scope">
          <span v-if="scope.row.loginNodeIp==null||scope.row.loginNodeIp==''">无</span>
          <span v-else>{{scope.row.loginNodeIp }}</span>
        </template>
      </el-table-column>
      <el-table-column label="使用的登录节点端口" align="center" prop="ldapLoginNodePort" >
        <template slot-scope="scope">
          <span v-if="scope.row.loginNodePort==null||scope.row.loginNodePort==''">无</span>
          <span v-else>{{scope.row.loginNodePort }}</span>
        </template>
      </el-table-column>

      <el-table-column label="备注" align="center" prop="remark" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">

          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleDetail(scope.row)"
            v-hasPermi="['aoh:cluster:edit']"
          >详情</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['aoh:cluster:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['aoh:cluster:remove']"
          >删除</el-button>

        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改集群对话框 -->
    <el-dialog :title="title" :visible.sync="open"  append-to-body>
      <el-transfer
        filterable
        filter-placeholder="请输入检索条件"
        v-model="info.alreadyAllocatetIdList"
        :data="info.allocateLdapAccountList"
        :change="handleChange()"
      >
      </el-transfer>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <el-dialog :title="title" :visible.sync="detailOpen"  append-to-body>
      <el-table
        :data="alreadyAllocatetAccountList"
        style="width: 100%">
        <el-table-column prop="clusterName" label="集群名" ></el-table-column>
        <el-table-column prop="loginNodeIp" label="登录节点"></el-table-column>
        <el-table-column prop="ldapUsername" label="集群账号"></el-table-column>
        <el-table-column prop="useStatus" label="使用状态">
          <template slot-scope="scope">
            <el-button v-model="scope.row.useStatus" @click="handleUpdateUseStatus(scope.row)">    {{selectDictLabel(useStatusOptions,scope.row.useStatus)}}</el-button>
          </template>
        </el-table-column>
      </el-table>

    </el-dialog>

  </div>
</template>

<script>
import { listAllocate ,getAllocateInfo,updateAllocateInfo,getAllocateDetail,updateUseStatus} from "@/api/ldap/allocate";
export default {
  name: "Cluster",
  components: {
  },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 分配表格数据
      ldapAllocateDTOList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        sysUserId:null,
        userName:null,
        userNickName:null,
        ldapUserName:null,
        clusterName:null,
        ldapUserCount:null,
        ldapLoginNodeIp:null,
        ldapLoginNodePort:null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      },
      statusOptions:[],
      useStatusOptions:[],
      info:{
        sysUserId:"",
        allocateLdapAccountList:[],
        alreadyAllocatetIdList:[],
      },
      alreadyAllocatetAccountList:[],
      detailOpen:false,
    };
  },
  created() {
    this.getDicts("sys_normal_disable").then(response => {
      this.statusOptions = response.data;
    });
    this.getDicts("ldap_account_use_status").then(response => {
      this.useStatusOptions = response.data;
    });
    this.getList();
  },
  methods: {
    /** 查询集群列表 */
    getList() {
      this.loading = true;
      listAllocate(this.queryParams).then(response => {
        this.ldapAllocateDTOList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.detailOpen=false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        userName:null,
        userNickName:null,
        ldapUserName:null,
        clusterName:null,
        ldapUserCount:null,
        ldapLoginNodeIp:null,
        ldapLoginNodePort:null,
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.clusterId)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },

    handleUpdateUseStatus(row){
      updateUseStatus(row).then(res=>{
        this.msgSuccess("修改成功");
        const  sysUserId=row.sysUserId
        getAllocateDetail(sysUserId).then(res=>{
          this.detailOpen=true;
          this.alreadyAllocatetAccountList=res.data
        })
      })
    },
    /**详情操作*/
    handleDetail(row){
      this.reset();
      const  sysUserId=row.sysUserId
      getAllocateDetail(sysUserId).then(res=>{
        this.detailOpen=true;
        this.alreadyAllocatetAccountList=res.data
      })

    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加集群";
    },
    handleChange(){
      this.reset();
      console.log(this.info.alreadyAllocatetIdList)
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      let sysUserId=row.sysUserId;
      getAllocateInfo(sysUserId).then(res=>{
        this.open=true;
        let tempList=[]

        for (const element of res.data.allocateLdapAccountList) {
          const  obj={
            label: element.clusterName+"-"+element.ldapUsername,
            key: element.ldapAccountId
          }
          tempList.push(obj)
        }
        this.info.sysUserId=res.data.sysUserId;

        this.info.allocateLdapAccountList=tempList
        this.info.alreadyAllocatetIdList=res.data.alreadyAllocatetIdList;
        console.log(this.info)
      })
    },
    /** 提交按钮 */
    submitForm() {
      updateAllocateInfo(this.info).then(res=>{
        this.open=false
        this.msgSuccess("更新成功");

      })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const clusterIds = row.clusterId || this.ids;
      this.$confirm('是否确认删除集群编号为"' + clusterIds + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        return delCluster(clusterIds);
      }).then(() => {
        this.getList();
        this.msgSuccess("删除成功");
      })
    },
    /** 修改状态 */
    handleStatusChange(row) {
      let text = row.status === "0" ? "启用" : "停用";
      this.$confirm('确认要' + text + '该数据吗?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        return changeStatus(row.clusterId, row.status);
      }).then(() => {
        this.msgSuccess(text + "成功");
      }).catch(function() {
        row.status = row.status === "0" ? "1" : "0";
      });
    },
    /** 导出按钮操作 */
    handleExport() {
      const queryParams = this.queryParams;
      this.$confirm('是否确认导出所有集群数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        return exportCluster(queryParams);
      }).then(response => {
        this.download(response.msg);
      })
    },
    handleFetch(row){
      fetchLdapUser(row.clusterId).then(res=>{
        console.log(res.data)
      })
    }
  }
};
</script>
