<template>

  <el-tabs type="border-card">
    <el-tab-pane label="公司/组织管理">
      <div class="app-container" style="height:43em">
      <el-form :model="comQueryParams" ref="queryForm" :inline="true" v-show="comShowSearch" label-width="88px">
        <el-form-item label="公司/组织名" prop="companyName">
          <el-input
            v-model="comQueryParams.companyName"
            placeholder="请输入公司/组织名"
            clearable
            size="small"
            @keyup.enter.native="handleQuery"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" size="mini" @click="comHandleQuery">搜索</el-button>
          <el-button icon="el-icon-refresh" size="mini" @click="comResetQuery">重置</el-button>
        </el-form-item>
      </el-form>

      <el-row :gutter="10" class="mb8">
        <el-col :span="1.5">
          <el-button
            type="primary"
            plain
            icon="el-icon-plus"
            size="mini"
            @click="comHandleAdd"
            v-hasPermi="['aoh:ldapGroup:add']"
          >新增</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button
            type="success"
            plain
            icon="el-icon-edit"
            size="mini"
            disabled
            v-hasPermi="['aoh:ldapGroup:edit']"
          >修改</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button
            type="danger"
            plain
            icon="el-icon-delete"
            size="mini"
            :disabled="comMultiple"
            @click="comHandleDelete"
            v-hasPermi="['aoh:ldapGroup:remove']"
          >删除</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button
            type="warning"
            plain
            icon="el-icon-download"
            size="mini"
            @click="comHandleExport"
            v-hasPermi="['aoh:ldapGroup:export']"
          >导出</el-button>
        </el-col>
        <right-toolbar :showSearch.sync="comShowSearch" @queryTable="comGetList"></right-toolbar>
      </el-row>

      <el-table v-loading="loading" :data="companyList" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55" align="center" />
        <el-table-column label="公司/组织id" align="center" prop="companyId" />
        <el-table-column label="公司/组织名称" align="center" prop="companyName" />
        <el-table-column label="公司/组织名简称" align="center" prop="companyShortName" />
        <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="text"
              icon="el-icon-edit"
              @click="comHandleUpdate(scope.row)"
              v-hasPermi="['aoh:ldapGroup:edit']"
            >修改</el-button>
            <el-button
              size="mini"
              type="text"
              icon="el-icon-delete"
              @click="comHandleDelete(scope.row)"
              v-hasPermi="['aoh:ldapGroup:remove']"
            >删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <pagination
        v-show="comTotal>0"
        :total="comTotal"
        :page.sync="comQueryParams.pageNum"
        :limit.sync="comQueryParams.pageSize"
        @pagination="comGetList"
      />

      <!-- 添加或修改Ldap 公司/组织 对话框 -->
      <el-dialog :title="title" :visible.sync="comOpen" width="500px" append-to-body>
        <el-form ref="comForm" :model="comForm" :rules="comRules" label-width="80px">
          <el-form-item label="公司/组织名称" prop="companyName">
            <el-input v-model="comForm.companyName" placeholder="请输入公司/组织名称" />
          </el-form-item>
          <el-form-item label="公司/组织名简称" prop="companyShortName">
            <el-input v-model="comForm.companyShortName" placeholder="请输入公司/组织名简称" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="comSubmitForm">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </el-dialog>
    </div><br><br><br><br><br><br>
    </el-tab-pane>
    <el-tab-pane label="群组管理">
      <div class="app-container" style="height:43em">
        <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="88px">
          <el-form-item label="群组名" prop="groupName">
            <el-input
              v-model="queryParams.groupName"
              placeholder="请输入群组名"
              clearable
              size="small"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>
          <el-form-item label="公司/组织名
" prop="companyName">
            <el-input
              v-model="queryParams.companyName"
              placeholder="请输入公司/组织名
"
              clearable
              size="small"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
            <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-form>

        <el-row :gutter="10" class="mb8">
          <el-col :span="1.5">
            <el-button
              type="primary"
              plain
              icon="el-icon-plus"
              size="mini"
              @click="handleAdd"
              v-hasPermi="['aoh:ldapGroup:add']"
            >新增</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button
              type="success"
              plain
              icon="el-icon-edit"
              size="mini"
              disabled
              v-hasPermi="['aoh:ldapGroup:edit']"
            >修改</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button
              type="danger"
              plain
              icon="el-icon-delete"
              size="mini"
              :disabled="multiple"
              @click="handleDelete"
              v-hasPermi="['aoh:ldapGroup:remove']"
            >删除</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button
              type="warning"
              plain
              icon="el-icon-download"
              size="mini"
              @click="handleExport"
              v-hasPermi="['aoh:ldapGroup:export']"
            >导出</el-button>
          </el-col>
          <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
        </el-row>

        <el-table v-loading="loading" :data="groupList" @selection-change="handleSelectionChange">
          <el-table-column type="selection" width="55" align="center" />
          <el-table-column label="群组号" align="center" prop="groupId" width="80"/>
          <el-table-column label="群组名" align="center" prop="groupName" />
          <el-table-column label="群组名简称" align="center" prop="groupShortName" />
          <el-table-column label="公司/组织名
" align="center" prop="companyName" />
          <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="text"
                icon="el-icon-edit"
                @click="handleUpdate(scope.row)"
                v-hasPermi="['aoh:ldapGroup:edit']"
              >修改</el-button>
              <el-button
                size="mini"
                type="text"
                icon="el-icon-delete"
                @click="handleDelete(scope.row)"
                v-hasPermi="['aoh:ldapGroup:remove']"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <pagination
          v-show="total>0"
          :total="total"
          :page.sync="queryParams.pageNum"
          :limit.sync="queryParams.pageSize"
          @pagination="getList"
        />

        <!-- 添加或修改Ldap 群组对话框 -->
        <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
          <el-form ref="form" :model="form" :rules="rules" label-width="110px">
            <el-form-item label="群组名" prop="groupName">
              <el-input v-model="form.groupName" placeholder="请输入群组名" />
            </el-form-item>
            <el-form-item label="群组名简称" prop="groupShortName">
              <el-input v-model="form.groupShortName" placeholder="请输入群组名简称" />
            </el-form-item>
            <el-form-item label="公司/组织名" prop="companyName">
<!--              <el-input v-model="form.companyId" placeholder="请输入公司/组织名" :disabled="selectDisable" />-->
              <el-select
                v-model="form.companyName"
                filterable
                remote
                reserve-keyword
                placeholder="请输入关键词"
                :remote-method="remoteMethod"
                :loading="selectLoading"
                :disabled="selectDisable">
                <el-option
                  v-for="item in selectOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="submitForm">确 定</el-button>
            <el-button @click="cancel">取 消</el-button>
          </div>
        </el-dialog>

        <el-dialog title="修改群组信息" :visible.sync="updateOpen" width="500px" append-to-body>
          <el-form ref="form" :model="form"  label-width="110px">
            <el-form-item label="群组名" prop="groupName">
              <el-input v-model="form.groupName" placeholder="请输入群组名" />
            </el-form-item>
            <el-form-item label="群组名简称" prop="groupShortName">
              <el-input v-model="form.groupShortName" placeholder="请输入群组名简称" />
            </el-form-item>

          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="submitForm">确 定</el-button>
            <el-button @click="cancel">取 消</el-button>
          </div>
        </el-dialog>
      </div><br><br><br><br><br><br></el-tab-pane>
  </el-tabs>

</template>

<script>
  import { listGroup, getGroup, delGroup, addGroup, updateGroup, exportGroup } from "@/api/ldap/group";
  import { listCompany, getCompany, delCompany, addCompany, updateCompany, exportCompany,getCompanyLists } from "@/api/ldap/company";

  export default {
    name: "Group",
    components: {
    },
    data() {
      return {
        selectDisable: false,
        // 遮罩层
        loading: true,
        selectLoading : false,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 显示搜索条件
        showSearch: true,
        // 总条数
        total: 0,
        // Ldap 群组表格数据
        groupList: [],
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        updateOpen :false,
        open: false,
        selectOptions:{},
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 10,
          groupName: null,
          groupShortName: null,
          companyId: null
        },
        // filter:{
        //   CompanyValue : ''
        // },
        // 表单参数
        form: {},
        // 表单校验
        rules: {
          groupName: [
            { required: true, message: "群组名不能为空", trigger: "blur" }
          ],
          groupShortName: [
            { required: true, message: "群组名简称不能为空", trigger: "blur" }
          ],
          companyName: [
            { required: true, message: "公司名不能为空", trigger: "blur" }
          ],
        },






        // 遮罩层
        comLoading: true,
        // 选中数组
        comIds: [],
        // 非单个禁用
        comSingle: true,
        // 非多个禁用
        comMultiple: true,
        // 显示搜索条件
        comShowSearch: true,
        // 总条数
        comTotal: 0,
        // Ldap 公司/组织 表格数据
        companyList: [],
        // 弹出层标题
        comTitle: "",
        // 是否显示弹出层
        comOpen: false,
        // 查询参数
        comQueryParams: {
          pageNum: 1,
          pageSize: 10,
          companyName: null,
          companyShortName: null
        },
        // 表单参数
        comForm: {},
        // 表单校验
        comRules: {
        }
      };
    },
    created() {
      this.getList();
    },
    methods: {
      remoteMethod(queryString){
        if (queryString != "") {
          getCompanyLists(queryString).then(response => {
            this.selectOptions = response;
            console.log(response)
            // 调用 callback 返回建议列表的数据
          })
        }
      },
      /** 查询Ldap 群组列表 */
      getList() {
        this.loading = true;
        listGroup(this.queryParams).then(response => {
          this.groupList = response.rows;
          this.total = response.total;
          this.loading = false;
        });
        listCompany(this.comQueryParams).then(response => {
          this.companyList = response.rows;
          this.comTotal = response.total;
          this.loading = false;
        });
      },
      comGetList() {
        this.loading = true;
        listCompany(this.comQueryParams).then(response => {
          this.companyList = response.rows;
          this.comTotal = response.total;
          this.loading = false;
        });
      },
      // 取消按钮
      cancel() {
        this.selectDisable = false;
        this.open = false;
        this.updateOpen = false;
        this.comOpen = false;
        this.selectOptions = {};
        this.form = {};
        this.reset();
      },
      // 表单重置
      reset() {
        this.form = {
          groupId: null,
          groupName: null,
          groupShortName: null,
          companyId: null
        };
        this.comForm = {
          companyId: null,
          companyName: null,
          companyShortName: null
        };
        this.resetForm("comForm");
        this.resetForm("form");
      },
      /** 搜索按钮操作 */
      handleQuery() {
        this.queryParams.pageNum = 1;
        this.getList();
      },
      comHandleQuery() {
        this.comQueryParams.pageNum = 1;
        this.comGetList();
      },
      /** 重置按钮操作 */
      resetQuery() {
        this.resetForm("queryForm");
        this.handleQuery();
      },
      comResetQuery() {
        this.resetForm("comQueryForm");
        this.comHandleQuery();
      },
      // 多选框选中数据
      handleSelectionChange(selection) {
        this.ids = selection.map(item => item.groupId)
        this.single = selection.length!==1
        this.multiple = !selection.length
      },
      comHandleSelectionChange(selection) {
        this.comIds = selection.map(item => item.companyId)
        this.comSingle = selection.length!==1
        this.comMultiple = !selection.length
      },
      /** 新增按钮操作 */
      handleAdd() {
        this.reset();
        this.selectDisable = false;
        this.open = true;
        this.title = "添加Ldap 群组";
      },
      comHandleAdd() {
        this.reset();
        this.comOpen = true;
        this.comTitle = "添加Ldap 公司/组织";
      },
      /** 修改按钮操作 */
      handleUpdate(row) {
        this.reset();
        this.form.companyName = row.companyName;
        this.selectDisable = true;
        const groupId = row.groupId || this.ids
        getGroup(groupId).then(response => {
          this.form = response.data;
          this.updateOpen = true;
          this.title = "修改Ldap 群组";
        });
      },
      comHandleUpdate(row) {
        this.reset();
        const companyId = row.companyId || this.ids
        getCompany(companyId).then(response => {
          this.comForm = response.data;
          this.comOpen = true;
          this.comTitle = "修改Ldap 公司/组织 ";
        });
      },
      /** 提交按钮 */
      submitForm() {
        this.$refs["form"].validate(valid => {
          if (valid) {
            if (this.form.groupId != null) {
              updateGroup(this.form).then(response => {
                this.msgSuccess("修改成功");
                this.open = false;
                this.getList();
              });
            } else {
              addGroup(this.form).then(response => {
                this.msgSuccess("新增成功");
                this.open = false;
                this.getList();
              });
            }
            this.selectDisable = false;
            this.selectOptions = {};
            this.open = false;
            this.updateOpen = false;
            this.form = {};
          }
        });
      },
      comSubmitForm() {
        this.$refs["comForm"].validate(valid => {
          if (valid) {
            if (this.comForm.companyId != null) {
              updateCompany(this.comForm).then(response => {
                this.msgSuccess("修改成功");
                this.comOpen = false;
                this.getList();
              });
            } else {
              addCompany(this.comForm).then(response => {
                this.msgSuccess("新增成功");
                this.comOpen = false;
                this.getList();
              });
            }
          }
        });
      },
      /** 删除按钮操作 */
      handleDelete(row) {
        const groupIds = row.groupId || this.ids;
        this.$confirm('是否确认删除Ldap 群组编号为"' + groupIds + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delGroup(groupIds);
        }).then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        })
      },
      comHandleDelete(row) {
        const companyIds = row.companyId || this.comIds;
        this.$confirm('是否确认删除Ldap 公司/组织 编号为"' + companyIds + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delCompany(companyIds);
        }).then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        })
      },
      /** 导出按钮操作 */
      handleExport() {
        const queryParams = this.queryParams;
        this.$confirm('是否确认导出所有Ldap 群组数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return exportGroup(queryParams);
        }).then(response => {
          this.download(response.msg);
        })
      },
      comHandleExport() {
        const queryParams = this.comQueryParams;
        this.$confirm('是否确认导出所有Ldap 公司/组织 数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return exportCompany(queryParams);
        }).then(response => {
          this.download(response.msg);
        })
      }

    }
  };
</script>
