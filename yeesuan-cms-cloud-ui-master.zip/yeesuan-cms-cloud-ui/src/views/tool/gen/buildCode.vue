<template>
  <!-- 导入表 -->
  <el-dialog title="代码生成" :visible.sync="visible" width="900px" top="5vh" append-to-body :close-on-click-modal="false" >
    <el-row>
      <el-table @row-click="clickRow" ref="table" :data="dbTableList" @selection-change="handleSelectionChange" height="260px">
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="fileName" label="文件名" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column prop="isExist" label="是否存在" min-width="30%">
          <template slot-scope="scope">
              <span v-if="scope.row.isExist == true" style="color: red;">已存在</span>
              <span v-if="scope.row.isExist == false" style="color: limegreen">不存在</span>
          </template>
        </el-table-column>
        <el-table-column prop="isChange" label="是否修改" min-width="30%">
          <template slot-scope="scope">
              <span v-if="scope.row.isChange == true" style="color: red;">已修改</span>
              <span v-if="scope.row.isChange == false" style="color: limegreen">未修改</span>
          </template>
        </el-table-column>
        <el-table-column prop="vpath" label="路径/目标路径" :show-overflow-tooltip="true"></el-table-column>
      </el-table>
    </el-row>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="handleImportTable">确 定</el-button>
      <el-button @click="visible = false">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
import {previewFile, buildFile} from "@/api/tool/gen";
export default {
  props: ["tableId"],
  data() {
    return {
      // 遮罩层
      visible: false,
      // 选中数组值
      tables: [],
      // 文件数据
      dbTableList: []
    };
  },
  methods: {
    // 显示弹框
    show() {
      setTimeout(() =>{
        this.getList();
        this.visible = true;
      }, 0);
    },
    formatterPath(row, col){
      if(row.isExist != true){
        return '-';
      }
      return row.vpath;
    },
    clickRow(row) {
      this.$refs.table.toggleRowSelection(row);
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.tables = selection.map(item => item.fileName);
    },
    // 查询文件数据
    getList() {
      previewFile(this.tableId).then(res => {
        if(res.code === 200){
          this.dbTableList = res.data;
        }
      });
    },
    /** 确定按钮操作 */
    handleImportTable() {
      buildFile({ files: this.tables.join(","), tableId: this.tableId }).then(res => {
        this.msgSuccess(res.msg);
        if (res.code === 200) {
          this.visible = false;
          this.$emit("ok");
        }
      });
    }
  }
};
</script>
