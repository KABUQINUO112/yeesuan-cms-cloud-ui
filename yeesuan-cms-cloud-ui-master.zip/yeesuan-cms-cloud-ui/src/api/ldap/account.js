import request from '@/utils/request'

// 查询ldap拉取的账号列表
export function listAccount(query) {
  return request({
    url: '/ldap/account/list',
    method: 'get',
    params: query
  })
}

// 查询ldap拉取的账号详细
export function getAccount(ldapAccountId) {
  return request({
    url: '/ldap/account/' + ldapAccountId,
    method: 'get'
  })
}
// 查询ldap拉取的账号详细
export function getDetail(ldapAccountId) {
  return request({
    url: '/ldap/account/detail/' + ldapAccountId,
    method: 'get'
  })
}



// 新增ldap拉取的账号
export function addAccount(data) {
  return request({
    url: '/ldap/account',
    method: 'post',
    data: data
  })
}

// 修改ldap拉取的账号
export function updateAccount(data) {
  return request({
    url: '/ldap/account',
    method: 'put',
    data: data
  })
}
// 修改ldap拉取的账号
export function updateTestAccount(data) {
  return request({
    url: '/ldap/account/updateTestAccount',
    method: 'put',
    data: data
  })
}

// 删除ldap拉取的账号
export function delAccount(ldapAccountId) {
  return request({
    url: '/ldap/account/' + ldapAccountId,
    method: 'delete'
  })
}

// 导出ldap拉取的账号
export function exportAccount(query) {
  return request({
    url: '/ldap/account/export',
    method: 'get',
    params: query
  })
}
