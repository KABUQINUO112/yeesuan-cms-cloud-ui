import request from '@/utils/request'

// 查询ldap拉取的账号列表
export function listAllocate(query) {
  return request({
    url: '/ldap/allocate/list',
    method: 'get',
    params: query
  })
}

// 查询ldap拉取的账号详细
export function getAllocateInfo(sysUserId) {
  return request({
    url: '/ldap/allocate/info/' + sysUserId,
    method: 'get'
  })
}

// 查询ldap拉取的账号详细
export function updateAllocateInfo(data) {
  return request({
    url: '/ldap/allocate/info/',
    method: 'put',
    data:data
  })
}


// 查询ldap拉取的账号详细
export function getAllocateDetail(sysUserId) {
  return request({
    url: '/ldap/allocate/detail/' + sysUserId,
    method: 'get'
  })
}


export function updateUseStatus(data){
  return request({
    url: '/ldap/allocate/detail/',
    method: 'put',
    data:data
  })
}
