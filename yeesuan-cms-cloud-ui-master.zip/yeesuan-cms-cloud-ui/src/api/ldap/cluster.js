import request from '@/utils/request'
import {param} from "../../utils";

// 查询集群列表
export function listCluster(query) {
  return request({
    url: '/ldap/cluster/list',
    method: 'get',
    params: query
  })
}
// 查询集群列表
export function allListCluster(query) {
  return request({
    url: '/ldap/cluster/allList',
    method: 'get',
    params: query
  })
}

// 查询集群详细
export function getCluster(clusterId) {
  return request({
    url: '/ldap/cluster/' + clusterId,
    method: 'get'
  })
}

// 新增集群
export function addCluster(data) {
  return request({
    url: '/ldap/cluster',
    method: 'post',
    data: data
  })
}

// 修改集群
export function updateCluster(data) {
  return request({
    url: '/ldap/cluster',
    method: 'put',
    data: data
  })
}

// 删除集群
export function delCluster(clusterId) {
  return request({
    url: '/ldap/cluster/' + clusterId,
    method: 'delete'
  })
}
//修改状态
export function changeStatus(clusterId, status) {
  const data = {
    clusterId,
    status
  }
  return request({
    url: '/ldap/cluster',
    method: 'put',
    data: data
  })
}
//修改状态
export function fetchLdapUser(clusterId) {
  return request({
    url: '/ldap/cluster/fetchLdapUser/'+clusterId,
    method: 'get',
  })
}
// 导出集群
export function exportCluster(query) {
  return request({
    url: '/ldap/cluster/export',
    method: 'get',
    params: query
  })
}

