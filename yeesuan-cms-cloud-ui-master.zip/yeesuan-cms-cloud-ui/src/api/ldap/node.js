import request from '@/utils/request'

// 查询登录节点列表
export function listNode(query) {
  return request({
    url: '/ldap/node/list',
    method: 'get',
    params: query
  })
}

// 查询登录节点列表
export function allListNode(query) {
  return request({
    url: '/ldap/node/allList',
    method: 'get',
    params: query
  })
}
// 查询登录节点详细
export function getNode(loginNodeId) {
  return request({
    url: '/ldap/node/' + loginNodeId,
    method: 'get'
  })
}

// 新增登录节点
export function addNode(data) {
  return request({
    url: '/ldap/node',
    method: 'post',
    data: data
  })
}

// 修改登录节点
export function updateNode(data) {
  return request({
    url: '/ldap/node',
    method: 'put',
    data: data
  })
}

// 删除登录节点
export function delNode(loginNodeId) {
  return request({
    url: '/ldap/node/' + loginNodeId,
    method: 'delete'
  })
}

// 导出登录节点
export function exportNode(query) {
  return request({
    url: '/ldap/node/export',
    method: 'get',
    params: query
  })
}

//修改状态
export function changeStatus(loginNodeId, status) {
  const data = {
    loginNodeId,
    status
  }
  return request({
    url: '/ldap/node',
    method: 'put',
    data: data
  })
}

