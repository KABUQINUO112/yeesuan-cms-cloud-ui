import request from '@/utils/request'

// 查询Ldap 群组列表
export function listGroup(query) {
  return request({
    url: '/ldap/ldapGroup/listDTO',
    method: 'get',
    params: query
  })
}

// 查询Ldap 群组详细
export function getGroup(groupId) {
  return request({
    url: '/ldap/ldapGroup/' + groupId,
    method: 'get'
  })
}

// 新增Ldap 群组
export function addGroup(data) {
  return request({
    url: '/ldap/ldapGroup',
    method: 'post',
    data: data
  })
}

// 修改Ldap 群组
export function updateGroup(data) {
  return request({
    url: '/ldap/ldapGroup',
    method: 'put',
    data: data
  })
}

// 删除Ldap 群组
export function delGroup(groupId) {
  return request({
    url: '/ldap/ldapGroup/' + groupId,
    method: 'delete'
  })
}

// 导出Ldap 群组
export function exportGroup(query) {
  return request({
    url: '/ldap/ldapGroup/export',
    method: 'get',
    params: query
  })
}
