import request from '@/utils/request'




// 查询Ldap 公司/组织 列表
export function getCompanyLists(query) {
  return request({
    url: '/ldap/ldapCompany/listCompanyList',
    method: 'post',
    data: query
  })
}

// 查询Ldap 公司/组织 列表
export function listCompany(query) {
  return request({
    url: '/ldap/ldapCompany/list',
    method: 'get',
    params: query
  })
}

// 查询Ldap 公司/组织 详细
export function getCompany(companyId) {
  return request({
    url: '/ldap/ldapCompany/' + companyId,
    method: 'get'
  })
}

// 新增Ldap 公司/组织
export function addCompany(data) {
  return request({
    url: '/ldap/ldapCompany',
    method: 'post',
    data: data
  })
}

// 修改Ldap 公司/组织
export function updateCompany(data) {
  return request({
    url: '/ldap/ldapCompany',
    method: 'put',
    data: data
  })
}

// 删除Ldap 公司/组织
export function delCompany(companyId) {
  return request({
    url: '/ldap/ldapCompany/' + companyId,
    method: 'delete'
  })
}

// 导出Ldap 公司/组织
export function exportCompany(query) {
  return request({
    url: '/ldap/ldapCompany/export',
    method: 'get',
    params: query
  })
}
