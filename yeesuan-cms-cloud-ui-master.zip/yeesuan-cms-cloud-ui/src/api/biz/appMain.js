import request from '@/utils/request'

// 查询软件表列表
export function listAppMain(query) {
  return request({
    url: '/biz/appMain/list',
    method: 'get',
    params: query
  })
}

// 查询软件表详细
export function getAppMain(id) {
  return request({
    url: '/biz/appMain/' + id,
    method: 'get'
  })
}

// 新增软件表
export function addAppMain(data) {
  return request({
    url: '/biz/appMain',
    method: 'post',
    data: data
  })
}

// 修改软件表
export function updateAppMain(data) {
  return request({
    url: '/biz/appMain',
    method: 'put',
    data: data
  })
}

// 删除软件表
export function delAppMain(id) {
  return request({
    url: '/biz/appMain/' + id,
    method: 'delete'
  })
}

// 导出软件表
export function exportAppMain(query) {
  return request({
    url: '/biz/appMain/export',
    method: 'get',
    params: query
  })
}

//取得领域数据
export function getFileds(){
  return request({
    url: '/biz/appField/getFields',
    method: 'get'
  })
}

//修改状态
export function changeStatus(id, status) {
  const data = {
    id,
    status
  }
  return request({
    url: '/biz/appMain/changeStatus',
    method: 'put',
    data: data
  })
}

//获取所有软件主表记录的id和name，主要用于页面下拉框数据
export function getAppMainData() {
  return request({
    url: '/biz/appMain/getAppMainData',
    method: 'post'
  })
}

//生成logo
export function getLogo(appName) {
  return request({
    url: '/file/createLogo',
    method: 'get',
    params: appName
  })
}
