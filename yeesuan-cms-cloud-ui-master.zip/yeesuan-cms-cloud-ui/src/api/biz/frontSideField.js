import request from '@/utils/request'

// 查询侧边栏领域列表
export function listFrontSideField(query) {
  return request({
    url: '/biz/frontSideField/list',
    method: 'get',
    params: query
  })
}

// 查询侧边栏领域详细
export function getFrontSideField(id) {
  return request({
    url: '/biz/frontSideField/' + id,
    method: 'get'
  })
}

// 新增侧边栏领域
export function addFrontSideField(data) {
  return request({
    url: '/biz/frontSideField',
    method: 'post',
    data: data
  })
}

// 修改侧边栏领域
export function updateFrontSideField(data) {
  return request({
    url: '/biz/frontSideField',
    method: 'put',
    data: data
  })
}

// 删除侧边栏领域
export function delFrontSideField(id) {
  return request({
    url: '/biz/frontSideField/' + id,
    method: 'delete'
  })
}

// 导出侧边栏领域
export function exportFrontSideField(query) {
  return request({
    url: '/biz/frontSideField/export',
    method: 'get',
    params: query
  })
}

//取得领域数据
export function getFileds(){
  return request({
    url: '/biz/appField/getFields',
    method: 'get'
  })
}
//取得侧边栏数据
export function getFrontSideList(){
  return request({
    url: '/biz/frontSide/getFrontSideList',
    method: 'get'
  })
}

// 侧边栏状态修改
export function changeSideStatus(id, status) {
  const data = {
    id,
    status
  }
  return request({
    url: '/biz/frontSideField',
    method: 'put',
    data: data
  })
}
