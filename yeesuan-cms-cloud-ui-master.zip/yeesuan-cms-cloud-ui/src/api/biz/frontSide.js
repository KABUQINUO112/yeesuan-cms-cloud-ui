import request from '@/utils/request'

// 查询侧边栏管理列表
export function listFrontSide(query) {
  return request({
    url: '/biz/frontSide/list',
    method: 'get',
    params: query
  })
}

// 查询侧边栏管理详细
export function getFrontSide(id) {
  return request({
    url: '/biz/frontSide/' + id,
    method: 'get'
  })
}

// 新增侧边栏管理
export function addFrontSide(data) {
  return request({
    url: '/biz/frontSide',
    method: 'post',
    data: data
  })
}

// 修改侧边栏管理
export function updateFrontSide(data) {
  return request({
    url: '/biz/frontSide',
    method: 'put',
    data: data
  })
}

// 删除侧边栏管理
export function delFrontSide(id) {
  return request({
    url: '/biz/frontSide/' + id,
    method: 'delete'
  })
}

// 导出侧边栏管理
export function exportFrontSide(query) {
  return request({
    url: '/biz/frontSide/export',
    method: 'get',
    params: query
  })
}

//修改状态
export function changeStatus(id, status) {
  const data = {
    id,
    status
  }
  return request({
    url: '/biz/frontSide/changeStatus',
    method: 'put',
    data: data
  })
}

//取得侧边栏主表list
export function getFrontSideList(){
  return request({
    url: '/biz/frontSide/getFrontSideList',
    method: 'get'
  })
}
