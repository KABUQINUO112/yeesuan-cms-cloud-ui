import request from '@/utils/request'

// 查询用户和首页软件推荐关联列表
export function listHomeRecAppUser(query) {
  return request({
    url: '/biz/homeRecAppUser/list',
    method: 'get',
    params: query
  })
}

// 查询用户和首页软件推荐关联详细
export function getHomeRecAppUser(userId) {
  return request({
    url: '/biz/homeRecAppUser/' + userId,
    method: 'get'
  })
}

// 新增用户和首页软件推荐关联
export function addHomeRecAppUser(data) {
  return request({
    url: '/biz/homeRecAppUser',
    method: 'post',
    data: data
  })
}

// 修改用户和首页软件推荐关联
export function updateHomeRecAppUser(data) {
  return request({
    url: '/biz/homeRecAppUser',
    method: 'put',
    data: data
  })
}

// 删除用户和首页软件推荐关联
export function delHomeRecAppUser(userId,appMainId) {
  return request({
    url: '/biz/homeRecAppUser/' + userId+'/'+appMainId,
    method: 'get'
  })
}

//取得appmainlist
export function getAppMainList(){
  return request({
    url: '/biz/homeRecAppUser/getAppMainList',
    method: 'get'
  })
}

//取得appmainlist
export function getSysUserList(){
  return request({
    url: '/biz/homeRecAppUser/getSysUserList',
    method: 'get'
  })
}