import request from '@/utils/request'

// 查询终端管理列表
export function listShell(query) {
  return request({
    url: '/biz/shell/list',
    method: 'get',
    params: query
  })
}

// 查询终端管理详细
export function getShell(id) {
  return request({
    url: '/biz/shell/' + id,
    method: 'get'
  })
}

// 新增终端管理
export function addShell(data) {
  return request({
    url: '/biz/shell',
    method: 'post',
    data: data
  })
}

// 修改终端管理
export function updateShell(data) {
  return request({
    url: '/biz/shell',
    method: 'put',
    data: data
  })
}

// 删除终端管理
export function delShell(id) {
  return request({
    url: '/biz/shell/' + id,
    method: 'delete'
  })
}

// 导出终端管理
export function exportShell(query) {
  return request({
    url: '/biz/shell/export',
    method: 'get',
    params: query
  })
}

//取得sysuser表list 
export function getSysUserList(){
  return request({
    url: '/biz/shell/getSysUserList',
    method: 'get'
  })
}
