import request from '@/utils/request'

// 查询软件领域列表
export function listAppField(query) {
  return request({
    url: '/biz/appField/list',
    method: 'get',
    params: query
  })
}

// 查询软件领域详细
export function getAppField(id) {
  return request({
    url: '/biz/appField/' + id,
    method: 'get'
  })
}

// 新增软件领域
export function addAppField(data) {
  return request({
    url: '/biz/appField',
    method: 'post',
    data: data
  })
}

// 修改软件领域
export function updateAppField(data) {
  return request({
    url: '/biz/appField',
    method: 'put',
    data: data
  })
}

// 删除软件领域
export function delAppField(id) {
  return request({
    url: '/biz/appField/' + id,
    method: 'delete'
  })
}

// 导出软件领域
export function exportAppField(query) {
  return request({
    url: '/biz/appField/export',
    method: 'get',
    params: query
  })
}

//修改状态
export function changeStatus(id, status) {
  const data = {
    id,
    status
  }
  return request({
    url: '/biz/appField/changeStatus',
    method: 'put',
    data: data
  })
}
