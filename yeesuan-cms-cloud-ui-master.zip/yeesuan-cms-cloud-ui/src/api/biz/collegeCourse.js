import request from '@/utils/request'

// 查询易算学院-课程 列表
export function listCollegeCourse(query) {
  return request({
    url: '/biz/collegeCourse/list',
    method: 'get',
    params: query
  })
}

// 查询易算学院-课程 详细
export function getCollegeCourse(id) {
  return request({
    url: '/biz/collegeCourse/' + id,
    method: 'get'
  })
}

// 新增易算学院-课程 
export function addCollegeCourse(data) {
  return request({
    url: '/biz/collegeCourse',
    method: 'post',
    data: data
  })
}

// 修改易算学院-课程 
export function updateCollegeCourse(data) {
  return request({
    url: '/biz/collegeCourse',
    method: 'put',
    data: data
  })
}

// 删除易算学院-课程 
export function delCollegeCourse(id) {
  return request({
    url: '/biz/collegeCourse/' + id,
    method: 'delete'
  })
}

// 导出易算学院-课程 
export function exportCollegeCourse(query) {
  return request({
    url: '/biz/collegeCourse/export',
    method: 'get',
    params: query
  })
}