import request from '@/utils/request'

// 查询dock默认应用管理列表
export function listDeskTopDockDefault(query) {
  return request({
    url: '/biz/desktopDockDefault/list',
    method: 'get',
    params: query
  })
}

// 查询dock默认应用管理详细
export function getDeskTopDockDefault(id) {
  return request({
    url: '/biz/desktopDockDefault/' + id,
    method: 'get'
  })
}

// 新增dock默认应用管理
export function addDeskTopDockDefault(data) {
  return request({
    url: '/biz/desktopDockDefault',
    method: 'post',
    data: data
  })
}

// 修改dock默认应用管理
export function updateDeskTopDockDefault(data) {
  return request({
    url: '/biz/desktopDockDefault',
    method: 'put',
    data: data
  })
}

// 删除dock默认应用管理
export function delDeskTopDockDefault(id) {
  return request({
    url: '/biz/desktopDockDefault/' + id,
    method: 'delete'
  })
}

// 导出dock默认应用管理
export function exportDeskTopDockDefault(query) {
  return request({
    url: '/biz/desktopDockDefault/export',
    method: 'get',
    params: query
  })
}
