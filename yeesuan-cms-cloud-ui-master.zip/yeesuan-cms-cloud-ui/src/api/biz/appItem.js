import request from '@/utils/request'

// 查询软件详情列表
export function listAppItem(query) {
  return request({
    url: '/biz/appItem/list',
    method: 'get',
    params: query
  })
}

// 查询手动添加软件详情列表
export function listAppItemManual(query) {
  return request({
    url: '/biz/appItem/listManual',
    method: 'get',
    params: query
  })
}

// 查询自动导入软件详情列表
export function listAppItemAuto(query) {
  return request({
    url: '/biz/appItem/listAuto',
    method: 'get',
    params: query
  })
}

// 查询软件详情详细
export function getAppItem(id) {
  return request({
    url: '/biz/appItem/' + id,
    method: 'get'
  })
}

// 新增软件详情
export function addAppItem(data) {
  return request({
    url: '/biz/appItem',
    method: 'post',
    data: data
  })
}

// 修改软件详情
export function updateAppItem(data) {
  return request({
    url: '/biz/appItem',
    method: 'put',
    data: data
  })
}

// 删除软件详情
export function delAppItem(id) {
  return request({
    url: '/biz/appItem/' + id,
    method: 'delete'
  })
}

// 导出软件详情
export function exportAppItem(query) {
  return request({
    url: '/biz/appItem/export',
    method: 'get',
    params: query
  })
}
//修改状态
export function changeStatus(id, status) {
  const data = {
    id,
    status
  }
  return request({
    url: '/biz/appItem/changeStatus',
    method: 'put',
    data: data
  })
}

//修改默认版本
export function changeDefaultVersion(id, appMainId, defaultVersion) {
  const data = {
    id,
    appMainId,
    defaultVersion
  }
  return request({
    url: '/biz/appItem/changeDefaultVersion',
    method: 'put',
    data: data
  })
}
