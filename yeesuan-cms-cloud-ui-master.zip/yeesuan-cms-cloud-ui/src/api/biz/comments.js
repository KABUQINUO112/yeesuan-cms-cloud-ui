import request from '@/utils/request'




// 查询用户留言列表
export function listComments(query) {
  return request({
    url: '/biz/userComments/list',
    method: 'get',
    params: query
  })
}


// 查询用户留言详细
export function getComments(id) {
  return request({
    url: '/biz/userComments/' + id,
    method: 'get'
  })
}

// 新增用户留言
export function addComments(data) {
  return request({
    url: '/biz/userComments/addOneComment',
    method: 'post',
    data: data
  })
}

// 修改用户留言
export function updateComments(data) {
  return request({
    url: '/biz/userComments',
    method: 'put',
    data: data
  })
}

// 删除用户留言
export function delComments(id) {
  return request({
    url: '/biz/userComments/' + id,
    method: 'delete'
  })
}

// 导出用户留言
export function exportComments(query) {
  return request({
    url: '/biz/userComments/export',
    method: 'get',
    params: query
  })
}
