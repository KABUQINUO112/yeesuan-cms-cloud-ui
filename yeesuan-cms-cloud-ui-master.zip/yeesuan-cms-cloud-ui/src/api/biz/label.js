import request from '@/utils/request'

// 查询标签列表
export function listLabel(query) {
  return request({
    url: '/biz/label/list',
    method: 'get',
    params: query
  })
}

// 查询标签详细
export function getLabel(id) {
  return request({
    url: '/biz/label/' + id,
    method: 'get'
  })
}

// 新增标签
export function addLabel(data) {
  return request({
    url: '/biz/label',
    method: 'post',
    data: data
  })
}

// 修改标签
export function updateLabel(data) {
  return request({
    url: '/biz/label',
    method: 'put',
    data: data
  })
}

// 删除标签
export function delLabel(id) {
  return request({
    url: '/biz/label/' + id,
    method: 'delete'
  })
}

// 导出标签
export function exportLabel(query) {
  return request({
    url: '/biz/label/export',
    method: 'get',
    params: query
  })
}

//修改状态
export function changeStatus(id, status) {
  const data = {
    id,
    status
  }
  return request({
    url: '/biz/label/changeStatus',
    method: 'put',
    data: data
  })
}
