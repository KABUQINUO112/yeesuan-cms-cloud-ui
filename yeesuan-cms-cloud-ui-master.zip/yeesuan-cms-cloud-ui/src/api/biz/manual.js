import request from '@/utils/request'

// 查询使用手册列表
export function listManual(query) {
  return request({
    url: '/biz/manual/list',
    method: 'get',
    params: query
  })
}

// 查询使用手册详细
export function getManual(ids) {
  return request({
    url: '/biz/manual/' + ids,
    method: 'get'
  })
}

// 新增使用手册
export function addManual(data) {
  return request({
    url: '/biz/manual',
    method: 'put',
    data: data
  })
}

// 修改使用手册
export function updateManual(data) {
  return request({
    url: '/biz/manual',
    method: 'put',
    data: data
  })
}

// 删除使用手册
export function delManual(ids) {
  return request({
    url: '/biz/manual/' + ids,
    method: 'delete'
  })
}
// 导出使用手册
export function exportManual(query) {
  return request({
    url: '/biz/manual/export',
    method: 'get',
    params: query
  })
}
