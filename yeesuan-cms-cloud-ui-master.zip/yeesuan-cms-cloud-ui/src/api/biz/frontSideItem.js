import request from '@/utils/request'

// 查询侧边栏软件管理列表
export function listFrontSideItem(query) {
  return request({
    url: '/biz/frontSideItem/list',
    method: 'get',
    params: query
  })
}

// 查询侧边栏软件管理详细
export function getFrontSideItem(id) {
  return request({
    url: '/biz/frontSideItem/' + id,
    method: 'get'
  })
}

// 新增侧边栏软件管理
export function addFrontSideItem(data) {
  return request({
    url: '/biz/frontSideItem',
    method: 'put',
    data: data
  })
}

// 修改侧边栏软件管理
export function updateFrontSideItem(data) {
  return request({
    url: '/biz/frontSideItem',
    method: 'put',
    data: data
  })
}

// 删除侧边栏软件管理
export function delFrontSideItem(id) {
  return request({
    url: '/biz/frontSideItem/' + id,
    method: 'delete'
  })
}

// 导出侧边栏软件管理
export function exportFrontSideItem(query) {
  return request({
    url: '/biz/frontSideItem/export',
    method: 'get',
    params: query
  })
}

//取得AppMain表list
export function getAppMainList(){
  return request({
    url: '/biz/frontSideItem/getAppMainList',
    method: 'get'
  })
}

//取得AppItem表list
export function getAppItemList(){
  return request({
    url: '/biz/frontSideItem/getAppItemList',
    method: 'get'
  })
}
//取得侧边栏主表list
export function getFrontSideList(){
  return request({
    url: '/biz/frontSide/getFrontSideList',
    method: 'get'
  })
}

//修改状态
export function changeStatus(id, status) {
  const data = {
    id,
    status
  }
  return request({
    url: '/biz/frontSideItem/changeStatus',
    method: 'put',
    data: data
  })
}
