import request from '@/utils/request'

// 查询轮播图路径列表
export function listBannerItem(query) {
  return request({
    url: '/biz/bannerItem/list',
    method: 'get',
    params: query
  })
}

// 查询轮播图路径详细
export function getBannerItem(id) {
  return request({
    url: '/biz/bannerItem/' + id,
    method: 'get'
  })
}

// 新增轮播图路径
export function addBannerItem(data) {
  return request({
    url: '/biz/bannerItem',
    method: 'post',
    data: data
  })
}

// 修改轮播图路径
export function updateBannerItem(data) {
  return request({
    url: '/biz/bannerItem',
    method: 'put',
    data: data
  })
}

// 删除轮播图路径
export function delBannerItem(id) {
  return request({
    url: '/biz/bannerItem/' + id,
    method: 'delete'
  })
}

// 导出轮播图路径
export function exportBannerItem(query) {
  return request({
    url: '/biz/bannerItem/export',
    method: 'get',
    params: query
  })
}
//取得领域数据
export function getLocation(){
  return request({
    url: '/biz/bannerItem/getLocation',
    method: 'get'
  })
}
