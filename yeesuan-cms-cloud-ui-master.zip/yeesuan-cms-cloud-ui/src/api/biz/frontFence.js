import request from '@/utils/request'

// 查询栏目软件列表
export function listFrontFence(query) {
  return request({
    url: '/biz/frontFence/getFences',
    method: 'get',
    params: query
  })
}

// 查询栏目软件详细
export function
getFrontFence(id) {
  return request({
    url: '/biz/frontFence/' + id,
    method: 'get'
  })
}

// 新增栏目软件
export function addFrontFence(data) {
  return request({
    url: '/biz/frontFence',
    method: 'post',
    data: data
  })
}

// 修改栏目软件
export function updateFrontFence(data) {
  return request({
    url: '/biz/frontFence',
    method: 'put',
    data: data
  })
}

// 删除栏目软件
export function delFrontFence(id) {
  return request({
    url: '/biz/frontFence/' + id,
    method: 'delete'
  })
}

// 导出栏目软件
export function exportFrontFence(query) {
  return request({
    url: '/biz/frontFence/export',
    method: 'get',
    params: query
  })
}
//取得领域数据
export function getFileds(){
  return request({
    url: '/biz/appField/getFields',
    method: 'get'
  })
}
//取得app默认详情数据
export function getApps(value){
  return request({
    url: 'biz/appMain/getAppByFieldId'+'?fieldId='+value,
    method: 'get',
  })
}

