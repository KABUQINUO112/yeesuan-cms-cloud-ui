import request from '@/utils/request'

// 查询视频和讲解人关系列表
export function listLecturer(query) {
  return request({
    url: '/biz/lecturer/list',
    method: 'get',
    params: query
  })
}

// 查询视频和讲解人关系详细
export function getLecturer(id) {
  return request({
    url: '/biz/lecturer/' + id,
    method: 'get'
  })
}

// 新增视频和讲解人关系
export function addLecturer(data) {
  return request({
    url: '/biz/lecturer',
    method: 'post',
    data: data
  })
}

// 修改视频和讲解人关系
export function updateLecturer(data) {
  return request({
    url: '/biz/lecturer',
    method: 'put',
    data: data
  })
}

// 删除视频和讲解人关系
export function delLecturer(id) {
  return request({
    url: '/biz/lecturer/' + id,
    method: 'delete'
  })
}

// 导出视频和讲解人关系
export function exportLecturer(query) {
  return request({
    url: '/biz/lecturer/export',
    method: 'get',
    params: query
  })
}
//取得视频表list
export function getVideoList(){
  return request({
    url: '/biz/lecturer/getVideoList',
    method: 'get'
  })
}