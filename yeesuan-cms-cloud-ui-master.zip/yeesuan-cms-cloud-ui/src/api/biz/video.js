import request from '@/utils/request'

// 查询视频管理列表
export function listVideo(query) {
  return request({
    url: '/biz/video/list',
    method: 'get',
    params: query
  })
}

// 查询视频管理详细
export function getVideo(id) {
  return request({
    url: '/biz/video/' + id,
    method: 'get'
  })
}

// 新增视频管理
export function addVideo(data) {
  return request({
    url: '/biz/video',
    method: 'post',
    data: data
  })
}

// 修改视频管理
export function updateVideo(data) {
  return request({
    url: '/biz/video',
    method: 'put',
    data: data
  })
}

// 删除视频管理
export function delVideo(id) {
  return request({
    url: '/biz/video/' + id,
    method: 'delete'
  })
}

// 导出视频管理
export function exportVideo(query) {
  return request({
    url: '/biz/video/export',
    method: 'get',
    params: query
  })
}
//取得讲解人表list
export function getLecturerList(){
  return request({
    url: '/biz/video/getLecturerList',
    method: 'get'
  })
}
//修改状态
export function changeStatus(id, status) {
  const data = {
    id,
    status
  }
  return request({
    url: '/biz/video/changeStatus',
    method: 'put',
    data: data
  })
}